from flask import Flask, render_template, Response
import cv2
import time
import mediapipe as mp
from comSerial import *
import pyaudio
import numpy as np
app = Flask(__name__)
from utils import * 
mp_face_detection = mp.solutions.face_detection.FaceDetection(min_detection_confidence=0.7)

class OzzyManager:
    def __init__(self):
        self.rest_pan = 95
        self.rest_tilt_left = 90
        self.rest_tilt_right = 110
        self.close_mouth = 90
        self.close_eye = [0, 0]
        self.open_eye = [1, 1]

        self.cont = 0
        self.more_faces = 0
        self.target_face_index = 0
        self.frame_count = 0
        self.last_seen_face_time = 0

        self.eye = self.close_eye
        self.face_x = self.rest_pan
        self.face_y = self.rest_pan

        self.mouth_move = 90 

        self.smooth_face_x = None
        self.smooth_face_y = None

        self.cap = cv2.VideoCapture(0)

        self.FORMAT = pyaudio.paInt16
        self.CHANNELS = 2 
        self.RATE = 44100
        self.CHUNK = 8192

        self.min_origem = -1000
        self.max_origem = 1000
        self.min_destino = 0
        self.max_destino = 180

        # Inicializar o PyAudio
        self.audio = pyaudio.PyAudio()

# Abrir o stream de áudio
        self.stream = self.audio.open(format=self.FORMAT, channels=self.CHANNELS,
                    rate=self.RATE, input=True,
                    input_device_index=8,  # Adjust based on your setup 4 | 6 
                    frames_per_buffer=self.CHUNK)


    def smooth(self, value, prev_value, alpha=0.3):
        return alpha * value + (1 - alpha) * prev_value

    def should_change_focus(self, new_face, current_face, tolerance=30):
        x_diff = abs(new_face[0] - current_face[0])
        y_diff = abs(new_face[1] - current_face[1])
        return x_diff > tolerance or y_diff > tolerance

    def process_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            print("Failed to capture frame")
            return None
        
        height, width, _ = frame.shape
        self.results = mp_face_detection.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        self.faces = []

        if self.results.detections:
            self.last_seen_face_time = time.time()
            for detection in self.results.detections:
                bboxC = detection.location_data.relative_bounding_box
                x = int(bboxC.xmin * width)
                y = int(bboxC.ymin * height)
                w = int(bboxC.width * width)
                h = int(bboxC.height * height)
                self.faces.append((x, y, w, h))
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

            if len(self.faces) > 0:
                self.handle_faces(frame)
        else:
            self.handle_no_faces(frame)

        return frame

    def handle_faces(self, frame):
        if len(self.faces) == 1:
            self.more_faces = 0
        else:
            self.more_faces = 1

        if self.frame_count % 125 == 0:
            new_target_face_index = (self.target_face_index + 1) % len(self.faces)
            if self.should_change_focus(self.faces[new_target_face_index], self.faces[self.target_face_index]):
                self.target_face_index = new_target_face_index

        if self.target_face_index < len(self.faces):
            target_face = self.faces[self.target_face_index]
            cv2.rectangle(frame, (target_face[0], target_face[1]), (target_face[0] + target_face[2], target_face[1] + target_face[3]), (0, 0, 255), 2)
            self.update_face_position(target_face)
            cv2.putText(frame, "PERSUE", (0, 480), cv2.FONT_HERSHEY_DUPLEX, 3.0, (125, 246, 55), 3)

            self.frame_count += 1

    def update_face_position(self, target_face):
        self.face_x_target = self.map_to_range(target_face[0], 0, self.cap.get(cv2.CAP_PROP_FRAME_WIDTH), 40, 110)
        self.face_y_target = self.map_to_range(target_face[1], 0, self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT), 40, 110)

        if self.smooth_face_x is None:
            self.smooth_face_x = self.face_x_target
            self.smooth_face_y = self.face_y_target
        else:
            self.smooth_face_x = self.smooth(self.face_x_target, self.smooth_face_x)
            self.smooth_face_y = self.smooth(self.face_y_target, self.smooth_face_y)

        self.face_x = self.move_to(self.face_x, self.smooth_face_x, 50)
        self.face_y = self.move_to(self.face_y, self.smooth_face_y, 50)

        pos = self.saturate(self.face_y, 180, 0)
        self.rest_tilt_right = 180 - pos
        self.rest_tilt_left = 0 + pos
        self.eye = self.open_eye

    def handle_no_faces(self, frame):
        timer_for_rest = time.time() - self.last_seen_face_time
        cv2.putText(frame, f"timee: {timer_for_rest:.2f}", (300, 480), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 0, 255), 3)

        if timer_for_rest > 2:
            cv2.putText(frame, "REST", (0, 480), cv2.FONT_HERSHEY_DUPLEX, 3.0, (125, 246, 55), 3)
            self.face_x = self.rest_pan
            self.eye = self.close_eye

    @staticmethod
    def map_to_range(value, in_min, in_max, out_min, out_max):
        return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

    @staticmethod
    def move_to(current, target, step):
        if current < target:
            return min(current + step, target)
        return max(current - step, target)

    @staticmethod
    def saturate(value, upper, lower):
        return max(lower, min(value, upper))

    def generate_frames(self):
        while True:
            frame = self.process_frame()
            if frame is None:
                continue

            _, buffer = cv2.imencode('.jpg', frame)
            current_frame = buffer.tobytes()

            data = np.frombuffer(self.stream.read(self.CHUNK, exception_on_overflow=False), dtype=np.int16)
        
            # Check if data has any elements
            if data.size > 0:
                normalized_data = data[0]  # Process the first sample
                if(normalized_data > self.max_origem):
                    normalized_data = self.max_origem

                if(normalized_data < self.min_origem):
                    normalized_data = self.min_origem
                
                self.mouth_move = int(mapear(normalized_data, self.min_origem, self.max_origem, self.min_destino, self.max_destino))
               
            self.angulos = [int(self.rest_tilt_left), int(self.rest_tilt_right), int(self.face_x),int(self.mouth_move)]
            print(self.angulos)
            cordenadas(self.angulos, self.eye, array)
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + current_frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    ozzy = OzzyManager()
    return Response(ozzy.generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=True)
